package search;

import java.util.List;
import java.util.*; 

/**
 * An implementation of a Searcher that performs an iterative search,
 * storing the list of next states in a Stack. This results in a
 * depth-first search.
 * 
 */
public class StackBasedDepthFirstSearcher<T> extends Searcher<T> {
	
	public StackBasedDepthFirstSearcher(SearchProblem<T> searchProblem) {
		super(searchProblem);
	}

	@Override
	public List<T> solve() {
		// TODO
		if (solution != null) {
			return solution;
		}

		Stack<T> path = new Stack<T>();		
		depthFirstSearcher(path);
		if (path.size() > 0) {
			if (!isValid(path)) {
				throw new RuntimeException(
						"searcher should never find an invalid solution!");
			}
		}
		return path;
	}

	private void depthFirstSearcher(Stack<T> path) {
		path.add(searchProblem.getInitialState());
		visitedStates.add(searchProblem.getInitialState());

		if (searchProblem.isGoalState(searchProblem.getInitialState())) {
			return;
		}
		
		T newNode = null;
		List<T> stor;
		while (!path.isEmpty() || !searchProblem.isGoalState(newNode)){
			stor = searchProblem.getSuccessors(path.peek()); 
			for (int i = 0; i < stor.size(); i++) {
				if (!visitedStates.contains(stor.get(i))) {
					newNode = stor.get(i);
				}	
			}	 

			if (newNode == null) {
				path.pop();
				continue; 
			} 

			visitedStates.add(newNode);
			path.push(newNode);
			newNode = null;
		}

	}

}
